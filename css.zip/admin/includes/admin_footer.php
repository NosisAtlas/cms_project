</div>
    <!-- /#wrapper -->

    

    <!-- Check box script -->
    <script src="js/scripts.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    <!-- CKEDITOR script -->
    <script>
    ClassicEditor
        .create( document.querySelector( '#content' ) )
        .catch( error => {
            console.error( error );
        } );
    </script>
    <!-- CKEDITOR script END -->
</body>

</html>