<?php 
    // Defining consts
    const _REGISTER = "Register";
    const _USERNAME = "Enter your desired username";
    const _EMAIL = "username@mail.com";
    const _PASSWORD = "Enter your desired password";
?>