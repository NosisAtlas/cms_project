<?php 
    // Defining consts
    const _REGISTER = "등록";
    const _USERNAME = "원하는 사용자 이름을 입력하세요";
    const _EMAIL = "username@mail.com";
    const _PASSWORD = "원하는 비밀번호를 입력하세요";
?>